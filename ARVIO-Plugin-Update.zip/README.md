# ARVIO Plugin System Update

## New Files (ADD to project)

### UI - Plugin Screen
- `app/src/main/kotlin/com/arflix/tv/ui/screens/plugin/PluginScreen.kt` - Plugin management screen UI
- `app/src/main/kotlin/com/arflix/tv/ui/screens/plugin/PluginUiState.kt` - State & Events definitions
- `app/src/main/kotlin/com/arflix/tv/ui/screens/plugin/PluginViewModel.kt` - ViewModel for plugin management

### Core Plugin System (sideload flavor only)
- `app/src/sideload/kotlin/com/arflix/tv/core/plugin/PluginManager.kt` - Main plugin manager (repository CRUD, scraper registration)
- `app/src/sideload/kotlin/com/arflix/tv/core/plugin/PluginRuntime.kt` - QuickJS JavaScript runtime for JS-based scrapers
- `app/src/sideload/kotlin/com/arflix/tv/core/plugin/cloudstream/ExternalExtensionLoader.kt` - APK plugin loader
- `app/src/sideload/kotlin/com/arflix/tv/core/plugin/cloudstream/ExternalExtensionRunner.kt` - Extension execution engine
- `app/src/sideload/kotlin/com/arflix/tv/core/plugin/cloudstream/ExternalExtractorRegistry.kt` - Extractor registry
- `app/src/sideload/kotlin/com/arflix/tv/core/plugin/cloudstream/ExternalRepoParser.kt` - manifest.json parser (Nuvio-style format)
- `app/src/sideload/kotlin/com/arflix/tv/core/plugin/cloudstream/TvTypeExtensions.kt` - Content type mappings

### Utilities
- `app/src/main/kotlin/com/arflix/tv/core/plugin/PluginSafety.kt` - Plugin safety utilities
- `app/src/main/kotlin/com/arflix/tv/core/plugin/TestDiagnostics.kt` - Diagnostic tools

## Modified Files (MERGE carefully)

### `app/src/main/kotlin/com/arflix/tv/ui/screens/settings/SettingsScreen.kt`
Changes made:
- Added PluginViewModel import and state collection
- Added `"plugins"` to the sections list (gated by `BuildConfig.FEATURE_PLUGINS_ENABLED`)
- Added `"plugins"` case in the content rendering block that shows `PluginScreen`
- Added focus bypass for plugin section: lines containing `currentSection == "plugins"` allow native Compose focus handling instead of the custom D-pad logic
- Added `onNavigateToSection` callback so DirectionLeft returns focus to sidebar

### `app/build.gradle.kts`
Changes made:
- Added `-Xskip-metadata-version-check` to `kotlinOptions.freeCompilerArgs` (required for compatibility with dependencies compiled with Kotlin 2.3.0 while project uses Kotlin 2.1.0)

### `build.gradle.kts` (root)
Changes made:
- Upgraded Hilt Gradle plugin from 2.54 to 2.57 (required to parse Kotlin 2.3.0 metadata from newer dependencies)

## Important Notes
- Plugin system is only active when `BuildConfig.FEATURE_PLUGINS_ENABLED = true`
- Supports Nuvio-style manifest.json format for repository definitions
- Scrapers from plugins register through `PluginManager` which interfaces with the existing `ScraperManager`
- The `AddRepoDialog` starts with an empty URL field - users paste their own repository URL
- All files preserve the original project directory structure for easy merging
